#include <iostream>
#include <string>
#include <sstream>
#include <fstream>

using namespace std;

string rleComp(string x);
string rleDecomp(string t);
string to_string(int x);


int main()
{
    string s1; //to store string to be compressed
    string s2; // to store string to be decompressed

    ifstream theFile("poem.txt");                                    //poem to compressed
    ifstream theOtherFile("poemComp.txt");                          //poem to be compressed
    ofstream anotherfile("comp.txt");                               //to store compressed /decompressed result

    cout<<"compressing ....."<<endl;

    while(getline(theFile,s1))
    {
        cout<<rleComp(s1)<<endl;
        anotherfile<<rleComp(s1)<<endl;
    }

    anotherfile<<"************************"<<endl; //separate line

    cout<<"************************"<<endl;
    cout<<"decompressing ....."<<endl;

    while(getline(theOtherFile,s2))
    {
        cout<<rleDecomp(s2)<<endl;
        anotherfile<<rleDecomp(s2)<<endl;
    }

    return 0;
}

//RLE compression function
string rleComp(string x)
{  int cnt=1;
   string OutStr=("");

     for( int i=0;i<x.length();i++)
    {
        if(x[i]==x[i+1]){
            cnt++;
       } else
        {if(cnt>1)
            {
                OutStr+=to_string(cnt);
                cnt=1;
            }
            OutStr.push_back(x[i]);
        }
    }
     return OutStr;
}

 //RLE decompression function
string rleDecomp(string t)
{  char c='0';             //used to convert char to integer

   string outstr2=("");
    for(int i=0; i<t.length(); i++)
    {

        if ('2'<=t[i] && t[i]<='9')
    {
            for(int n=1; n< (t[i]-c) ; n++)
    {
        outstr2+=t[i+1];
    }
    }else
        outstr2+=t[i];
}
return outstr2;
}

//integer to string function
string to_string(int x)
{
    stringstream ss;
    ss<<x;
    return ss.str();
}



